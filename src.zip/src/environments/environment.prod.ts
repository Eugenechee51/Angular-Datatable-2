export const environment = {
  production: true,
  inMemoryDatabase:false
};
